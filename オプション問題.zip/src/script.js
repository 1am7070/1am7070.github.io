message="Hello World"
console.log(message)  //課題１
var array1 = ['apple','mango','banana'];
for(var i =0; i <array1.length; i++){console.log(array1[i]);}     //課題2&3
var formula="1"
for(var i =2;i<=100;i=i+1){formula+="+"+String(i); var answer=((1+i)*i)/ 2; console.log(formula +"="+String(answer));}  //課題4